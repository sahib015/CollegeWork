<?php
session_start();
?><?php
include 'connect.php';
?>
<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$DOB=$_POST['DOB'];
$email=$_POST['email'];
$password= $_POST['password'];
$payment= $_POST['payment_method'];
$card= $_POST['credit_card_no'];
$expiry= $_POST['expiry_date'];
$address= $_POST['Address'];
$city= $_POST['City'];
$zip=$_POST['Zip_code'];


//insert to mysql (database)
$sql= "UPDATE customers SET fname='$fname', lname= '$lname',DOB='$DOB',email='$email', password='$password', type_of_credit_card='$payment',credit_number='$card',expiry_date='$expiry' WHERE fname='$fname'";
mysql_query($sql);

echo mysql_error();


// What to display when succcessful
if ($_POST["update"])
{echo "<script>alert('You have successfully updated !!')</script>";
echo "<script>window.open('profile.php'_self')</script>";
}else
echo mysql_error();

?>
