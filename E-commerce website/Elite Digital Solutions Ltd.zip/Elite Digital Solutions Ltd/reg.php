<?php
// This line includes a file that would be accessed to connect to the database server.
include 'connect.php';

// Get values from the forms
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$DOb=$_POST['DOB'];
$email=$_POST['email'];
$password= $_POST['password'];
$payment= $_POST['payment_method'];
$card= $_POST['credit_card_no'];
$expiry= $_POST['expiry_date'];


//insert to mysql (database)
$sql="INSERT INTO customers (fname, lname, dob,email, password,type_of_credit_card,credit_number,expiry_date)
VALUES ('$fname', '$lname','$DOB','$email','$password','$payment','$card','$expiry')";
$result= mysql_query($sql);

// What to display when succcessful
if ($_POST["submit"])
{echo "<script>alert('You have successfully registered !!')</script>";
header ('location:index.php');
}
else
// What to display when unsucccessful
{echo "ERROR";
}
//close Mysql
mysql_close()
?>