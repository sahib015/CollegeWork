<?php
session_start();
$from=$_SESSION['currentuser'];
$email="sahibjabbal@hotmail.com";
$subject="New order from ".$from;
$remainqty= $_POST['qty_remain'];
$name=$_POST['p_name'];

include 'connect.php';
	$product_id = $_GET[id];
foreach($_SESSION['cart'] as $product_id  => $quantity){
	$sql = sprintf("SELECT p_image,p_name, p_price, p_qty FROM products WHERE product_id = %d;",
								$product_id); 
					
				$result = mysql_query($sql);
					
				//Only display the row if there is a product (though there should always be as we have already checked)
				if(mysql_num_rows($result) > 0) {
$message= "Name of product: ".$name.
			"\n Quantity: ".$_POST['qty'].
			"\n Price: ". $_POST['price'].
			"\n Sub total: Ksh ". $_POST['total']. 
			"\n Shipping details of: ". $from.
			"\n Address: ".$_POST['address'].
			"\n City: ".$_POST['city'].
			"\n Zip code: ". $_POST['postal']
			
			;}}
		mail($email,$subject,$message,"From: ".$from);
		unset( $_SESSION['cart']);
//Update to mysql (database)
include'connect.php';
$sql="UPDATE products SET p_qty='$remainqty' WHERE p_name='$name'";
mysql_query($sql);

echo mysql_error();
		
			
echo "<script>alert('Your order has been received. you will receive an confirmation email shortly.')</script>";

echo "<script>window.open('index.php','_self')</script>";
				
?>