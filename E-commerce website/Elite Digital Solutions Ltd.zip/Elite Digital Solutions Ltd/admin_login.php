 <?php
session_start();
include 'connect.php';

if(isset($_POST['alogin'])){

	$username=$_POST['a_username'];
	$pass=$_POST['a_password'];
	


$query="select * from admin where username='$username' AND password='$pass'";
$run=mysql_query($query) or die (mysql_error());

if(mysql_num_rows($run)==1){
	$_SESSION['currentadmin'] = $_POST['a_username'];

	echo "<script>alert('Your Logged in Successfully !!')</script>";
	echo "<script>window.open('admin.php','_self')</script>";
	
}else{
	echo "<script>alert('Wrong username and password, please try again !!')</script>";
	echo "<script>window.open('index.php','_self')</script>";
}}
?>