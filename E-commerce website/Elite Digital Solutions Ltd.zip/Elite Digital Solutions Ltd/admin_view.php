<?php
session_start();
$id=$_REQUEST['view'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>View</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
	
	function set_url(id){
		var e = document.getElementById("holdp_id").innerHTML=id;
		alert (e);
		
		}
//-->
</script>
</head>

<body>
<!-- start popup view-->
<div id="popup-view" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-view');"><img align="right" src="Images/close.png" /></a>
       <?php
include 'connect.php';


$query= "SELECT * FROM products where product_id='$id'";
$result=mysql_query($query) or die (mysql_error());
while($row = mysql_fetch_array($result))
{?>
<h3> <?php echo $row["p_name"];?></h3>
         
          <img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width="150" height="150" /><br>
                  
            <strong>Description: </strong><br /> 
                    <?php echo $row["p_description"];?><br>

            <strong>Category</strong>: <br><?php echo $row["p_category"];?><br>
           
            <strong>Price:</strong><br><?php echo $row["p_price"];?><br>
          <?php
}?>
         
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup view-->
</body>
</html>