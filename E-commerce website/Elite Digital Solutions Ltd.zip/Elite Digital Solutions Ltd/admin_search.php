<?php
 
session_start();

if(!isset($_SESSION['currentadmin'])){
	header('location: index.php');
}


?>
<?php
include'connect.php';

if (!isset($_POST['search'])){
	header("location:index.php");
}
$search_sql="SELECT * FROM  `products` WHERE  `p_category` LIKE '". $_POST['search']."'
OR  `p_model` LIKE  '". $_POST['search']."'";
$search_query= mysql_query($search_sql);
if(mysql_num_rows($search_query)!=0){
$search_rs= mysql_fetch_assoc($search_query);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="tabmenu.css" />
<link rel="stylesheet" type="text/css" href="specialoffers.css" />
<title>Admin</title>
</head>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
	
	function set_url(id){
		var e = document.getElementById("holdp_id").innerHTML=id;
		alert (e);
		
		}
//-->
</script>
 


<style>
#categories{
	margin-top:1500px;
}

</style>
<body onload="">

<table border="0px" cellspacing="2px" cellpadding="2px" width="100%" id="header">
<tr>
<td></td>
<td>
<label class="header_text">Call Us: +254 20 375 3500-06 </label>  <label class="header_text">Email us: info@elitedigital.co.ke</label></td>
<td>
<?php
		// This code displays the current user who is logged into the website as
     if (isset($_SESSION['currentadmin'])){
		
include'connect.php';
// This is selecting the user from the customers table in the database
$query= "SELECT * FROM admin "; 
	$result=mysql_query($query) or die (mysql_error());
	$row = mysql_fetch_array($result);
	echo "<label class='header_text'>Welcome ".$_SESSION['currentadmin']."</label>";?><br />
       
        <a class="header_text"href="logout.php">Logout</a> 
        <style type="text/css">
        #login{
display:none;
}
#reg{
display:none;
}
        </style>
        
      </p>
        <?php
		}else
		// if the user is not logged in, this is displayed
		echo "<label class='header_text'>Welcome Guest</label>";
		echo "<br>";
		?>
        <label ><a id="login"class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');">Login</a> </label>
<label> </label>
</td>
</tr>
<tr>
<td>
<img src="Images/logo.jpg" />
</td>
<td>
<form method="post" action="admin_search.php">
<label class="header_text">Search: </label>
<input type="text"  name="search" size="50"/>
<input type="submit" value=" Search"/> 

</form>
</td>
<td></td>
</tr>
</table>
<nav>
<div class="nav">
<ul>
<li> <a href="admin.php" >View Products</a></li>
<Li> <a href="admin_update.php">Update Products</a></li>
<li> <a href="admin_delete.php">Delete Products</a></li>
<li><a href="admin_view_customer.php" class="header_text">View Customers</a></li>
<li><a href="admin_products.php" class="header_text">Insert Product</a></li>
<li><a href="#" class="header_text">View Orders</a></li>


</ul>
</div>
</nav>          
        
        <br/>
        <!-- start popup view-->
<div id="popup-view" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-view');"><img align="right" src="Images/close.png" /></a>
       <?php
include 'connect.php';
$_SESSION['view']=$result['product_id'];

$id=$_GET['view'];

$query= "SELECT * FROM products where product_id='$id'";
$result=mysql_query($query) or die (mysql_error());
while($row = mysql_fetch_array($result))
{?>
 <h3> <?php echo $row["p_name"];?></h3>
         
          <img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width="150" height="150" /><br>
                  
            <strong>Description: </strong><br /> 
                    <?php echo $row["p_description"];?><br>

            <strong>Category</strong>: <br><?php echo $row["p_category"];?><br>
           
            <strong>Price:</strong><br><?php echo $row["p_price"];?><br>
          <?php
}?>
         
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup view-->

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td width="15%" id="sidebarnav">
</td>
<td>
<table border="0" cellpadding="2" cellspacing="2">
<tr>

<td>

<h3>Search <?php include 'connect.php';
echo $_POST['search'];
?></h3>
<?php
if(mysql_num_rows($search_query)!=0){
	do {?>
		
       <table>
       <tr><td>
<a href="product_details.php?view=<?php echo $search_rs["product_id"]; ?>""><img src="<?php echo"product_inventory/";echo $search_rs["p_image"];?>  " width="100" height="100" /></a></td>
		
		<td> <a href="product_details.php?view=<?php echo $search_rs["product_id"]; ?>"""><?php echo $search_rs['p_name'];?></a><br>
		<?php
		 echo $search_rs['p_price'];
		 
		echo "</td>";
		echo "</tr>";?>
		<?php } while($search_rs= mysql_fetch_assoc($search_query));{
		
	}
	
} else{
	echo "No results found";
	}
	
?>









</td></tr>

</table>
</td>
</tr></table>

</body>
</html>