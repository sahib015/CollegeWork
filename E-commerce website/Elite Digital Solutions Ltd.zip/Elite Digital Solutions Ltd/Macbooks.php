<?php
session_start();
$_SESSION['currentpage']=$_SERVER['PHP_SELF'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="tabmenu.css" />
<link rel="stylesheet" type="text/css" href="specialoffers.css" />
<title>Macbooks</title>
</head>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script> 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="https:ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
<script type="text/javascript">
function Slider(){
$(".slider #1").show("slide",{direction:'right'},5000);
$(".slider #1").delay(500).hide("slide",{direction: 'left'},5000);
var sc =$(".slider img").size();
var count= 2;

setInterval(function(){
	$(".slider #"+count).show("slide", {direction: 'right'},5000);
	$(".slider #"+count).delay(5000).hide("slide",{direction: 'left'},5000);
	
	if(count==sc){
		count=1
	}else{
		count= count+1
		}
		},15000);

	}



</script>
<body onload="Slider();">
<table border="0px" cellspacing="2px" cellpadding="2px" width="100%" id="header">
<tr>
<td></td>
<td>
<label class="header_text">Call Us: +254 20 375 3500-06 </label>  <label class="header_text">Email us: info@elitedigital.co.ke</label></td>
<td>
<?php
		// This code displays the current user who is logged into the website as
     if (isset($_SESSION['currentuser'])){
		
include'connect.php';
// This is selecting the user from the customers table in the database
$query= "SELECT * FROM customers "; 
	$result=mysql_query($query) or die (mysql_error());
	$row = mysql_fetch_array($result);
		echo "<label class='header_text'>Welcome ".$_SESSION['currentuser']."</label>";?>
      <a class="header_text" href="profile.php?profile=<?php echo $_SESSION['currentuser']; ?>""">View Profile</a></p>
      <p><?php echo "<br>";?>
        <a class="header_text"href="logout.php">Logout</a>
        <style type="text/css">
        #login{
display:none;
}
#reg{
display:none;
}
        </style>
        
      </p>
        <?php
		}else
		// if the user is not logged in, this is displayed
		echo "<label class='header_text'>Welcome Guest</label>";
		echo "<br>";
		?>
        <label ><a id="login"class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');">Login</a> </label>
<label><a id="reg" class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');">Register </a></label>
</td>
</tr>
<tr>
<td>
<img src="Images/logo.jpg" />
</td>
<td>
<form method="post" action="search_results.php">
<label class="header_text">Search: </label>
<input type="text"  name="search" size="50"/>
<input type="submit" value=" Search"/> 

</form>
</td>
<td></td>
</tr>
</table>
<nav>
<div class="nav">
<ul>
<li> <a href="index.php" >Home</a></li>
<li> <a href="products.php">Products</a></li>
<Li> <a href="About_Us.php">About Us</a></li>
<li> <a href="Contact_Us.php">Contact Us</a></li>
<li><div id="shoppingcart">
<?php
    if (isset($_SESSION['currentuser'])){
echo "<a href='shoppingcart.php?action=none><img src='images/Shopping-Cart1-300x300.jpg' name='cart' width='50' height='50' id='cart' /></a>";
} else
echo "<a href='shoppingcart.php'<img src='images/shopping-cart-hi.png' name='cart' width='50' height='50' id='cart'/></a>";
?>
    <a href="shoppingcart.php?action="none""><img src="images/Shopping-Cart1-300x300.jpg" name="cart" width="50" height="50" id="cart" /></a></div></li>

</ul>
</div>
</nav>          
        
        <br/>
<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td width="15%" id="sidebarnav" height="250px">
<div>
<h4 class="header_text">Categories</h4>
<li><a href="iPads.php" class="header_text">iPads</a></li>
<li><a href="iphones.php" class="header_text">iPhones</a></li>
<li><a href="ipods.php" class="header_text">iPods</a></li>
<li><a href="Macbooks.php" class="header_text">Macbooks</a></li>
<li><a href="iMacs.php" class="header_text">iMacs</a></li>
<li><a href="Accessories.php" class="header_text">Accessories</a></li>
</div>
</td>
<td>
<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td>
<h2>Macbooks</h2>
<h3>Macbook Pro</h3>
<a href="mackbook_pro.php">More</a>
<?php
		  // This code selects records from the following fields in the products table
	   include 'connect.php';
$query= "SELECT product_id, p_image, p_name, p_price FROM products WHERE p_model='Macbook Pro' LIMIT 3";
	$result=mysql_query($query) or die (mysql_error());
	echo "<table>";
echo "<tr>";
// if the sql statement is true this loop is performed
while($row = mysql_fetch_array($result))
{ 


echo "<td>";
// the following records are displayed(echoed) from the database in the following format
?>
		  <a href="product_details.php?view=<?php echo $row["product_id"]; ?>""><img src="<?php echo"product_inventory/";echo $row["p_image"];?>  " width="100" height="100" /></a><?php echo "</td>";
echo "<td>" ;?>

<p> <a href="product_details.php?view=<?php echo $row["product_id"]; ?>"><?php echo $row["p_name"];?></a></p>
<?php
echo $row["p_price"];
echo "</form>";
echo "</td>";
}
echo "</tr>";
	echo "</table>";


	?>

</td>
</tr>
<tr>
<td>
<h3>Macbook Air</h3>

<?php
		  // This code selects records from the following fields in the products table
	   include 'connect.php';
$query= "SELECT product_id, p_image, p_name, p_price FROM products WHERE p_model='Macbook Air'";
	$result=mysql_query($query) or die (mysql_error());
	echo "<table>";
echo "<tr>";
// if the sql statement is true this loop is performed
while($row = mysql_fetch_array($result))
{ 


echo "<td>";
// the following records are displayed(echoed) from the database in the following format
?>
		  <a href="product_details.php?view=<?php echo $row["product_id"]; ?>""><img src="<?php echo"product_inventory/";echo $row["p_image"];?>  " width="100" height="100" /></a><?php echo "</td>";
echo "<td>" ;?>

<p> <a href="product_details.php?view=<?php echo $row["product_id"]; ?>"><?php echo $row["p_name"];?></a></p>
<?php
echo $row["p_price"];
echo "</form>";
echo "</td>";
}
echo "</tr>";
	echo "</table>";


	?>
</td>

</tr>
</table>
<!-- start popup login-->
<div id="popup-login" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');"><img align="right" src="Images/close.png" /></a>
        <table border="0" cellspacing="2" cellpadding="2">
        <tr>
        <td>
        <h3> Customer Login</h3>
        <form method="post" action="customer_login.php">
        Email:<input type="email" name="email" /><br />
        Password:<input type="password" name="cpassword" /><br />
        <input type="submit" value="Login" name="clogin"/>
        </form></td>
        <td>
         <h3>Admin Login</h3>
        <form method="post" action="">
        Email:<input type="text" name="acusername" /><br />
        Password:<input type="password" name="apassword" /><br />
        <input type="submit" value="Login" name="alogin"/>
        </form></td>
        <tr>
        </table>
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup login-->

<!-- start popup reg-->
<div id="popup-reg" class="popup-position">
	<div id="popup-wrapper">
    	<div id="popup-container">
       <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');"><img align="right" src="Images/close.png" /></a>
        <h2> Sign-Up</h2></center>
        <form method="post" action="reg.php">
        <table> <tr><td>
          First Name:</td><td>
          <input type="text" name="fname"/></td></tr>
          <tr><td>
          Last Name:</td><td>
          <input type="text" name="lname" /></td></tr>
     		<tr><td>
          Date of Birth:</td><td><input type="date" name="DOB" /></td></tr>
         <tr><td>
          Email:</td>
          <td>
          <input type="email" name="email" /></td>
          </tr><td>
          Pasword:</td><td>
          <input type="password" name="password" /></td></tr>
        	<tr><td>
          Please select payment method:</td><td>
          <select name="payment_method">
            <option value="Master Card">Master Card</option>
          
            <option value="Visa">Visa</option>
           
            <option value="PayPal">PayPal</option>
          
          </select></td></tr>
          <tr><td>
          Credit Card Number:</td><td>
          <input type="text" name="credit_card_no" /></td>
         <tr><td>
          Expiry Date:</td><td><input type="date" name="expiry_date" /></td>
          <tr><td>
        
        <input type="submit" value="Register" name="submit" align="middle" /></td></tr></table>
        </form>
        </div>    <!-- end of popup container-->
    </div><!-- end reg wrapper-->
</div><!-- end popup reg--></td>

</table>
</body>
</html>