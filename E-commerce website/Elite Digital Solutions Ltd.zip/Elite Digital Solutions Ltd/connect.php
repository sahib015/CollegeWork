<?php
// declaring the variables
$db_hostname="localhost";
$db_username="elite";
$db_password="elite";
$db_database="elite";

//connecting to the server

$db_server = mysql_connect ($db_hostname, $db_username, $db_password)
or die ("You are unable to connect to the database server".mysql_error());

//connect to the database
mysql_select_db ($db_database)
or die ("You are unable to connect to the database, try again".mysql_error());
?>