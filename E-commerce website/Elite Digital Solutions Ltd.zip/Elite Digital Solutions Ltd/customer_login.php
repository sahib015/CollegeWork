<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script> 

 <?php
session_start();
?>
<?php
include 'connect.php';

if(isset($_POST['clogin'])){

	$email=$_POST['email'];
	$pass=$_POST['cpassword'];
	
	
$query="select * from customers where email='$email' AND password='$pass'";
$run=mysql_query($query) or die (mysql_error());

if(mysql_num_rows($run)!=0){
	$_SESSION['currentuser'] = $_POST['email'];

$currentpage=$_SESSION['currentpage'];
//echo $currentpage;
echo "<script>window.open('$currentpage','_self')</script>";
	
}else {
	$currentpage=$_SESSION['currentpage'];
echo "<script>alert('Wong username and password, please try again')</script>";
echo "<script>window.open('$currentpage','_self')</script>";}

}
?>