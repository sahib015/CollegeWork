<?php
$id=$_REQUEST['view_product'];
session_start();
if(!isset($_SESSION['currentadmin'])){
	header('location: index.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="tabmenu.css" />
<link rel="stylesheet" type="text/css" href="specialoffers.css" />
<title>Welcome to Elite Digital Solutions</title>
</head>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script> 

<style>
#categories{
	margin-top:1500px;
}

</style>
<body>
<table border="0px" cellspacing="2px" cellpadding="2px" width="100%" id="header">
<tr>
<td></td>
<td>
<label class="header_text">Call Us: +254 20 375 3500-06 </label>  <label class="header_text">Email us: info@elitedigital.co.ke</label></td>
<td>
<?php
		// This code displays the current user who is logged into the website as
     if (isset($_SESSION['currentadmin'])){
		
include'connect.php';
// This is selecting the user from the customers table in the database
$query= "SELECT * FROM admin "; 
	$result=mysql_query($query) or die (mysql_error());
	$row = mysql_fetch_array($result);
	echo "<label class='header_text'>Welcome ".$_SESSION['currentadmin']."</label>";?><br />
       
        <a class="header_text"href="logout.php">Logout</a> 
        <style type="text/css">
        #login{
display:none;
}
#reg{
display:none;
}
        </style>
        
      </p>
        <?php
		}else
		// if the user is not logged in, this is displayed
		echo "<label class='header_text'>Welcome Guest</label>";
		echo "<br>";
		?>
        <label ><a id="login"class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');">Login</a> </label>
<label><a id="reg" class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');">Register </a></label>
</td>
</tr>
<tr>
<td>
<img src="Images/logo.jpg" />
</td>
<td>
<form method="post" action="admin_search.php">
<label class="header_text">Search: </label>
<input type="text"  name="search" size="50"/>
<input type="submit" value=" Search"/> 

</form>
</td>
<td></td>
</tr>
</table>
<nav>
<nav>
<div class="nav">
<ul>
<li> <a href="admin.php" >View Products</a></li>
<Li> <a href="admin_update.php">Update Products</a></li>
<li> <a href="admin_delete.php">Delete Products</a></li>
<li><a href="admin_view_customer.php" class="header_text">View Customers</a></li>
<li><a href="admin_products.php" class="header_text">Insert Product</a></li>



</ul>
</div>
</nav>          
        
        <br/>

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td width="15%" id="sidebarnav">
</td>
<td>

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td>


</td>
</tr>
</table>
<!-- start popup login-->
<div id="popup-update" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-update');"><img align="right" src="Images/close.png" /></a>
       		 <?php
include 'connect.php';
$query= "SELECT * FROM products where product_id='$id'";
$result=mysql_query($query) or die (mysql_error());
while($row = mysql_fetch_array($result))
{?>
          <form method="post" action="update_products_details.php" enctype="multipart/form-data">
          <img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width="150" height="150" /><br>
                    Name of product:<input type="text" name="p_name" value="<?php echo $row["p_name"];?>" /><br/>
          
          Description: <br /><textarea cols="70" rows="10" name="description" > <?php echo $row["p_description"];?>
</textarea><br />
          Category: <input type="text" name="category" value="<?php echo $row["p_category"];?>"/><br />
          Quantity: <input type="text" name="qty" value="<?php echo $row["p_qty"];?>"/><br />
            Model: <input type="text" name="model" value="<?php echo $row["p_model"];?>"/><br />
          Price:<input type="text" name="p_price" value="<?php echo $row["p_price"];?>" />
          <br />
          <input type="submit" value="Update" name="update" />
          </form><?php
}?>
        
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup login-->

<!-- start popup reg-->
<div id="popup-reg" class="popup-position">
	<div id="popup-wrapper">
    	<div id="popup-container">
       <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');"><img align="right" src="Images/close.png" /></a>
        <h2> Sign-Up</h2></center>
        <form method="post" action="reg.php">
        <table> <tr><td>
          First Name:</td><td>
          <input type="text" name="fname"/></td></tr>
          <tr><td>
          Last Name:</td><td>
          <input type="text" name="lname" /></td></tr>
     		<tr><td>
          Date of Birth:</td><td><input type="date" name="DOB" /></td></tr>
         <tr><td>
          Email:</td>
          <td>
          <input type="email" name="email" /></td>
          </tr><td>
          Pasword:</td><td>
          <input type="password" name="password" /></td></tr>
        	<tr><td>
          Please select payment method:</td><td>
          <select name="payment_method">
            <option value="Master Card">Master Card</option>
          
            <option value="Visa">Visa</option>
           
            <option value="PayPal">PayPal</option>
          
          </select></td></tr>
          <tr><td>
          Credit Card Number:</td><td>
          <input type="text" name="credit_card_no" /></td>
         <tr><td>
          Expiry Date:</td><td><input type="date" name="expiry_date" /></td>
          <tr><td>
        
        <input type="submit" value="Register" name="submit" align="middle" /></td></tr></table>
        </form>
        </div>    <!-- end of popup container-->
    </div><!-- end reg wrapper-->
</div><!-- end popup reg-->

<!-- start popup view-->
<div id="popup-login" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-view');"><img align="right" src="Images/close.png" /></a>
        <table border="0" cellspacing="2" cellpadding="2">
        <tr>
        <td>
         <?php
include 'connect.php';
$query= "SELECT * FROM products where product_id='$id'";
$result=mysql_query($query) or die (mysql_error());
while($row = mysql_fetch_array($result))
{?>
         
          <img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width="150" height="150" /><br>
                    <strong>Name of product</strong>:<?php echo $row["p_name"];?><br>
            <strong>Description: </strong><br /> 
                    <?php echo $row["p_description"];?><br>

            <strong>Category</strong>: <br><?php echo $row["p_category"];?><br>
            <strong>Brand:</strong><br><?php echo $row["p_brand"];?><br>
            <strong>Price:</strong><br><?php echo $row["p_price"];?><br>
          <?php
}?>
         </td>
        <tr>
        </table>
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup login-->
<table border="0" cellpadding="2" cellspacing="2">
<tr>

<td>
<h3>Products</h3>
  
        
<?php
          include'connect.php' ;
		  $sql="SELECT * FROM products";
		  $query= mysql_query($sql);?>
	  <tr> <td></td><td><strong>Name</strong></td><td><strong>Description</strong></td><td><strong>Price</strong></td><td><strong>Category</strong></td><td><strong>Quantity</strong></td><td><strong>Model</strong></td><td><strong>action</strong></td></tr>
          <?php
          while ($result=mysql_fetch_array($query))
{?>
<tr>
<td> <img  src="<?php echo"product_inventory/";echo $result["p_image"];?>  "" width="50" height="50" /> </td>
<td><?php echo $result["p_name"];?></td>
<td><?php echo $result["p_description"];?></td>
<td><?php echo $result["p_price"];?></td>
<td><?php echo $result["p_category"];?></td>
<td><?php echo $result["p_qty"];?></td>
<td><?php echo $result["p_model"];?></td>
<td><p> <a href="update_products.php?view_product=<?php echo $result["product_id"]; ?>">Update</a></p></td>
</tr>

	<?php }
		  ?>









</td>

</table>
</td>
</tr></table>


</body>
</html>