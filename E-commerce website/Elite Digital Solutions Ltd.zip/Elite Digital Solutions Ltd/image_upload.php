<?php
header("location:admin_products.php");
?>
<?php
include 'connect.php';

?>
<?php
//echo "This is PHP";



//Plant Characteristics

$pname=$_POST['p_name'];

$description=$_POST['description'];
$category=$_POST['category'];
$qty=$_POST['qty'];
$model=$_POST['model'];
$price=$_POST['p_price'];
$image=$_FILES["file"]["name"];



echo $pname;
echo $tittle;
echo $description;
echo $category;
echo $qty;
echo $model;
echo $price;
echo $image;


//Insert Into More
$query="INSERT INTO products(p_image, p_name, p_description, p_price, p_category,p_qty,p_model) VALUES ('".$image."', '".$pname."','".$description."','".$price."','".$category."','".$qty."','".$model."')";  

mysql_query($query) or die (mysql_error());

//Image Upload
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/png")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 70000000))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
  // echo "Upload: " . $_FILES["file"]["name"] . "<br />";
  // echo "Type: " . $_FILES["file"]["type"] . "<br />";
  // echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
  // echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

    if (file_exists("product_inventory/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "product_inventory/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "product_inventory/" . $_FILES["file"]["name"];
      }
    }
  }
else
  {
  echo mysql_error();
  }
?>