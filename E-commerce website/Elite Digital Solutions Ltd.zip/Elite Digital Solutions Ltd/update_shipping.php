<?php
include 'connect.php';
?>
<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$DOB=$_POST['DOB'];
$email=$_POST['email'];
$password= $_POST['password'];
$payment= $_POST['payment_method'];
$card= $_POST['credit_card_no'];
$expiry= $_POST['expiry_date'];
$address= $_POST['address'];
$city= $_POST['city'];
$zip=$_POST['postal'];
$id=$_POST['id'];


//insert to mysql (database)
$sql= "UPDATE customers SET Address='$address', City= '$city',Zip_code='$zip' WHERE customer_id='$id'";
mysql_query($sql);

echo mysql_error();


// What to display when succcessful
if ($_POST["submit"])
{echo "<script>alert('You have successfully updated !!')</script>";
header ('location:profile?profile= $_SESSION[currentuser]; .php');
}else{ echo "<script>alert('update Unsuccessful !!')</script>";}
//header ('location:profile.php');}
?>
