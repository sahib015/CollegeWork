<?php
$id=$_REQUEST['view_product'];
session_start();
if(!isset($_SESSION['currentadmin'])){
	header('location: index.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="tabmenu.css" />
<link rel="stylesheet" type="text/css" href="specialoffers.css" />
<title>Admin</title>
</head>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script> 

<style>
#categories{
	margin-top:1500px;
}

</style>
<body>
<table border="0px" cellspacing="2px" cellpadding="2px" width="100%" id="header">
<tr>
<td></td>
<td>
<label class="header_text">Call Us: +254 20 375 3500-06 </label>  <label class="header_text">Email us: info@elitedigital.co.ke</label></td>
<td>
<?php
		// This code displays the current user who is logged into the website as
     if (isset($_SESSION['currentadmin'])){
		
include'connect.php';
// This is selecting the user from the customers table in the database
$query= "SELECT * FROM admin "; 
	$result=mysql_query($query) or die (mysql_error());
	$row = mysql_fetch_array($result);
	echo "<label class='header_text'>Welcome ".$_SESSION['currentadmin']."</label>";?><br />
       
        <a class="header_text"href="logout.php">Logout</a> 
        <style type="text/css">
        #login{
display:none;
}
#reg{
display:none;
}
        </style>
        
      </p>
        <?php
		}else
		// if the user is not logged in, this is displayed
		echo "<label class='header_text'>Welcome Guest</label>";
		echo "<br>";
		?>
        <label ><a id="login"class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');">Login</a> </label>
<label><a id="reg" class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');">Register </a></label>
</td>
</tr>
<tr>
<td>
<img src="Images/logo.jpg" />
</td>
<td>
<form method="post" action="admin_search.php">
<label class="header_text">Search: </label>
<input type="text"  name="search" size="50"/>
<input type="submit" value=" Search"/> 

</form>
</td>
<td></td>
</tr>
</table>
<nav>
<div class="nav">
<ul>
<li> <a href="admin.php" >View Products</a></li>
<Li> <a href="admin_update.php">Update Products</a></li>
<li> <a href="admin_delete.php">Delete Products</a></li>
<li><a href="admin_view_customer.php" class="header_text">View Customers</a></li>
<li><a href="admin_products.php" class="header_text">Insert Product</a></li>



</ul>
</div>
</nav>          
        
        <br/>

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td width="15%" id="sidebarnav">
</td>
<td>

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td>


</td>
</tr>
</table>
<table border="0" cellpadding="2" cellspacing="2">
<tr>

<td>
<h3>View Customers</h3>
<table border="2" cellpadding="2" cellspacing="2">
<td><strong>First Name</strong></td>
<td><strong>Last Name</strong></td>
<td><strong>Address</strong></td>
<td><strong>Email</strong></td>
<td><strong>City</strong></td></tr>

<tr>
<?php 
 include'connect.php';
 $sql="SELECT * FROM customers";
 $query= mysql_query($sql);
 while ($result=mysql_fetch_array($query))
 {?>
 <tr>
 <td><?php echo $result["fname"];?></td>
 <td><?php echo $result["lname"];?></td>
 <td><?php echo $result["Address"];?></td>
  <td><?php echo $result["email"];?></td>
  <td><?php echo $result["City"];?></td>
  <?php }
 ?>
</tr>


</table>

  
        









</td></tr>

</table>
</td>
</tr></table>


</body>
</html>