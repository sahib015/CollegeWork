<?php
$name=$_POST['name'];
$from=$_POST['email'];
$email="sahibjabbal@hotmail.com";
$subject="New message from ".$from;
$message= $_POST['message'];
mail($email,$subject,$message,"From: ".$from);

echo "<script>alert('Your message has been sent.')</script>";

echo "<script>window.open('Contact_Us.php','_self')</script>";
?>