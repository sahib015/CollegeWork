<?php
session_start();
$from=$_SESSION['currentuser'];
$email="sahibjabbal@hotmail.com";
$subject="New order request of ". $_POST['p_name']." from ".$from;
$total= $_POST['p_price'] * $_POST['p_qty'];
$name=$_POST['p_name'];

include 'connect.php';
$message= "Name of product: ".$name.
			"\n Quantity: ".$_POST['p_qty'].
			"\n Price: ". $_POST['p_price'].
			"\n Sub total: Ksh ". $total
			
			;
		mail($email,$subject,$message,"From: ".$from);
		
			
echo "<script>alert('Your order request has been received. You will get an email when the product is available.')</script>";

echo "<script>window.open('index.php','_self')</script>";
				
?>