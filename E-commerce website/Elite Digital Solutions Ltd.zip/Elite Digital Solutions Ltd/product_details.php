<?php
session_start();
$id=$_REQUEST['view'];
$_SESSION['currentpage']=$_SERVER['PHP_SELF']."?view=".$id;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="tabmenu.css" />
<link rel="stylesheet" type="text/css" href="specialoffers.css" />
<title>Welcome to Elite Digital Solutions</title>
</head>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script> 

<style>
#categories{
	margin-top:-150px;
}

</style>
<body>
<table border="0px" cellspacing="2px" cellpadding="2px" width="100%" id="header">
<tr>
<td></td>
<td>
<label class="header_text">Call Us: +254 20 375 3500-06 </label>  <label class="header_text">Email us: info@elitedigital.co.ke</label></td>
<td>
<?php
		// This code displays the current user who is logged into the website as
     if (isset($_SESSION['currentuser'])){
		
include'connect.php';
// This is selecting the user from the customers table in the database
$query= "SELECT * FROM customers "; 
	$result=mysql_query($query) or die (mysql_error());
	$row = mysql_fetch_array($result);
	echo "<label class='header_text'>Welcome ".$_SESSION['currentuser']."</label>";?><br />
       <a class="header_text" href="profile.php?profile=<?php echo $_SESSION['currentuser']; ?>">View Profile</a><br />
      
        <a class="header_text"href="logout.php">Logout</a> 
        <style type="text/css">
        #login{
display:none;
}
#reg{
display:none;
}
        </style>
        
      </p>
        <?php
		}else
		// if the user is not logged in, this is displayed
		echo "<label class='header_text'>Welcome Guest</label>";
		echo "<br>";
		?>
        <label ><a id="login"class="header_text" href="javascript:void(0)?view=<?php echo $id;?>"onclick="toggle_visibility('popup-login');">Login</a> </label>
<label><a id="reg" class="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');">Register </a></label>
</td>
</tr>
<tr>
<td>
<img src="Images/logo.jpg" />
</td>
<td>
<form method="post" action="search_results.php">
<label class="header_text">Search: </label>
<input type="text"  name="search" size="50"/>
<input type="submit" value=" Search"/> 

</form>
</td>
<td></td>
</tr>
</table>
<nav>
<div class="nav">
<ul>
<li> <a href="index.php" >Home</a></li>
<li> <a href="products.php">Products</a></li>
<Li> <a href="About_Us.php">About Us</a></li>
<li> <a href="Contact_Us.php">Contact Us</a></li>
<li><div id="shoppingcart">
<?php
    if (isset($_SESSION['currentuser'])){
echo "<a href='shoppingcart.php?action=none><img src='images/Shopping-Cart1-300x300.jpg' name='cart' width='50' height='50' id='cart' /></a>";
} else
echo "<a href='shoppingcart.php'<img src='images/shopping-cart-hi.png' name='cart' width='50' height='50' id='cart'/></a>";
?>
    <a href="shoppingcart.php?action="none""><img src="images/Shopping-Cart1-300x300.jpg" name="cart" width="50" height="50" id="cart" /></a></div></li>

</ul>
</div>
</nav>          
        
        <br/>

<table border="0" cellpadding="2px" cellspacing="2px">
<tr>
<td width="15%" id="sidebarnav">
<div id="categories">
<h4 class="header_text">Categories</h4>
<li><a href="iPads.php" class="header_text">iPads</a></li>
<li><a href="iphones.php" class="header_text">iPhones</a></li>
<li><a href="ipods.php" class="header_text">iPods</a></li>
<li><a href="Mackbooks.php" class="header_text">Macbooks</a></li>
<li><a href="iMacs.php" class="header_text">iMacs</a></li>
<li><a href="Accessories.php" class="header_text">Accessories</a></li>
</div>

</td>
<td>

<!-- start popup login-->
<div id="popup-login" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-login');"><img align="right" src="Images/close.png" /></a>
        <table border="0" cellspacing="2" cellpadding="2">
        <tr>
        <td>
        <h3> Customer Login</h3>
        <form method="post" action="customer_login.php">
        Email:<input type="email" name="email" /><br />
        Password:<input type="password" name="cpassword" /><br />
        <input type="submit" value="Login" name="clogin"/>
        </form></td>
        <td>
         <h3>Admin Login</h3>
        <form method="post" action="admin_login.php">
        username:<input type="text" name="a_username" /><br />
        Password:<input type="password" name="a_password" /><br />
        <input type="submit" value="Login" name="alogin"/>
        </form></td>
        <tr>
        </table>
        </div>    <!-- end of popup container-->
    </div><!-- end login wrapper-->
</div><!-- end popup login-->

<!-- start popup reg-->
<div id="popup-reg" class="popup-position">
	<div id="popup-wrapper">
    	<div id="popup-container">
       <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-reg');"><img align="right" src="Images/close.png" /></a>
        <h2> Sign-Up</h2></center>
        <form method="post" action="reg.php">
        <table> <tr><td>
          First Name:</td><td>
          <input type="text" name="fname"/></td></tr>
          <tr><td>
          Last Name:</td><td>
          <input type="text" name="lname" /></td></tr>
     		<tr><td>
          Date of Birth:</td><td><input type="date" name="DOB" /></td></tr>
         <tr><td>
          Email:</td>
          <td>
          <input type="email" name="email" /></td>
          </tr><td>
          Pasword:</td><td>
          <input type="password" name="password" /></td></tr>
        	<tr><td>
          Please select payment method:</td><td>
          <select name="payment_method">
            <option value="Master Card">Master Card</option>
          
            <option value="Visa">Visa</option>
           
            <option value="PayPal">PayPal</option>
          
          </select></td></tr>
          <tr><td>
          Credit Card Number:</td><td>
          <input type="text" name="credit_card_no" /></td>
         <tr><td>
          Expiry Date:</td><td><input type="date" name="expiry_date" /></td>
          <tr><td>
        
        <input type="submit" value="Register" name="submit" align="middle" /></td></tr></table>
        </form>
        </div>    <!-- end of popup container-->
    </div><!-- end reg wrapper-->
</div><!-- end popup reg-->

<!-- start popup image-->
<div id="popup-img" class="popup-position">
	<div id="popup-wrapper">
   
    	<div id="popup-container">
         <a id="header_text" href="javascript:void(0)"onclick="toggle_visibility('popup-img');"><img align="right" src="Images/close.png" /></a>
         <?php
         include 'connect.php';
		 $query= "SELECT * FROM products where product_id='$id'";
$result=mysql_query($query) or die (mysql_error());
while($row = mysql_fetch_array($result))
{?>
<h3> <?php echo $row["p_name"];?></h3>
         
          <img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width=400" height="400" /><?php }
		 ?>
        
        </div>    <!-- end of popup container-->
    </div><!-- end image wrapper-->
</div><!-- end popup image-->
<table border="0" cellpadding="2" cellspacing="2">
<tr>

<td>
<h3>Product Details</h3>
 <?php
	   include 'connect.php';
$query= "SELECT product_id, p_image, p_name, p_price ,p_description, p_qty FROM products where product_id= $id";
	$result=mysql_query($query) or die (mysql_error());
	echo "<table>";
echo "<tr>";
?>

<?php
while($row = mysql_fetch_array($result))
{ 


echo "<td>";
?>
<?php
$_SESSION['img']=$row['product_id'];
?>
    <a href="javascript:void(0)?view_product=<?php  echo $_SESSION['img'];?>"onclick="toggle_visibility('popup-img');"><img  src="<?php echo"product_inventory/";echo $row["p_image"];?>  "" width="250" height="250" /></a>  <?php echo "</td>";
echo "<td>" ;?>

<p> <strong> <?php echo $row["p_name"];?></strong></p>
<?php
echo "<strong>Description: </strong>";
echo "<br>";
echo  $row["p_description"];
echo"<br>";
echo"<br>";
?> 

<strong><?php echo "Price:";
echo $row["p_price"];?></strong>
<br>
<br>

<?php

if($row['p_qty']==0){
		echo"<label style='color: #EB0000;'><strong>OUT OF STOCK</strong></label>";
		echo "<br>";
		if (isset($_SESSION['currentuser'])){
			echo"
			<form method='post' action='mailorderrequest.php'>
			<input type='hidden' value='$row[p_name]' name='p_name'> <br>
			<strong>Quantity:</strong>
			<input type='text' size='4' name=
			'p_qty'><br>
				<input type='hidden' value='$row[p_price]' name='p_price'> <br>
			<input type='submit' style='color: #006C00; padding: 10px;' value='Place an Order' name='submit'>
			</form>
			
			";
			}
		
		} else{
			echo "<strong>Number in Stock:  </strong>";
echo "      ";

echo  $row["p_qty"];
echo "      ";
			echo"<label style='color:#006C00;'><strong>IN STOCK</strong></label>";
			echo"<br><br>";
			if (isset($_SESSION['currentuser'])){
				
			echo "<a href='shoppingcart.php?action=add&id=$id'>Add to Cart</a>";
			}}

echo"<br>";
echo"<br>";
?>
<?php

echo "</td>";
}
echo "</tr>";
echo "</table>";?>






</td></tr>


</table></td></tr></table>
</body>
</html>