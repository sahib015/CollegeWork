<?php
// This line includes a file that would be accessed to connect to the database server.
include 'connect.php';

// Get values from the forms
$pname=$_POST['p_name'];
$description=$_POST['description'];
$category=$_POST['category'];
$model=$_POST['model'];
$qty=$_POST['qty'];
$price=$_POST['p_price'];

//Update to mysql (database)
$sql="UPDATE products SET p_description='$description',p_price='$price',p_category='$category',p_model='$model',p_qty='$qty' WHERE p_name='$pname'";
mysql_query($sql);

echo mysql_error();
// What to display when succcessful
if ($_POST["update"])
{echo "<script>alert('You have successfully updated !!')</script>";
header ('location:admin_update.php');
}else
// What to display when unsucccessful
echo mysql_error();
?>