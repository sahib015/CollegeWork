<?php
// This line includes a file that would be accessed to connect to the database server.
include 'connect.php';
//geting a record from a previous page
if (isset($_GET['delete'])){
	//declaring the value as a variable 
	$id=$_GET['delete'];
//Delete from mysql (database)
	$delete= "DELETE FROM products WHERE product_id={$id}";
	mysql_query($delete) or die (mysql_error());
	//What is displayed when successful
	echo "<script>alert('Record Successfully deleted')</script>          ";
	header	("location:admin_delete.php");
	exit();
}
?>