-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2018 at 11:59 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `slibrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'ssj', 'ssj123');

-- --------------------------------------------------------

--
-- Table structure for table `bbooks`
--

CREATE TABLE `bbooks` (
  `borrow_id` int(11) NOT NULL auto_increment,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `b_tittle` varchar(50) NOT NULL,
  `b_author` varchar(50) NOT NULL,
  `b_category` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL default 'Borrowed',
  PRIMARY KEY  (`borrow_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bbooks`
--

INSERT INTO `bbooks` (`borrow_id`, `fname`, `lname`, `b_tittle`, `b_author`, `b_category`, `status`) VALUES
(1, 'Sahib', 'Jabbal', 'Going Solo- The thrilling sequel to boy', 'Roald Dahl ', 'Fiction', 'Returned'),
(2, 'Anonymous', 'Hacker', 'Artemis Fowl and the Time Paradox', 'Eoin Colfer', 'Fiction', 'Returned'),
(3, 'John', 'Smith', 'Going Solo- The thrilling sequel to boy', 'Roald Dahl ', 'Fiction', 'Returned'),
(4, 'Sahib ', 'Jabbal', 'Golden Goal', 'Dan Freedman', 'Fiction', 'Returned');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL auto_increment,
  `b_tittle` varchar(50) NOT NULL,
  `b_author` varchar(25) NOT NULL,
  `b_isbn` bigint(18) NOT NULL,
  `b_category` varchar(25) NOT NULL,
  `b_availability` varchar(25) NOT NULL,
  PRIMARY KEY  (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `b_tittle`, `b_author`, `b_isbn`, `b_category`, `b_availability`) VALUES
(2, 'Going Solo- The thrilling sequel to boy', 'Roald Dahl ', 9780140325287, 'Fiction', 'Available'),
(3, 'Artemis Fowl and the Time Paradox', 'Eoin Colfer', 978014138330, 'Non-Fiction', 'Available'),
(4, 'Cambridge IGCSE Computer Studies Coursebook', 'Chris Leadbetter', 9780521170635, 'Textbooks', 'Available'),
(5, 'Golden Goal', 'Dan Freedman', 9781407102955, 'Fiction', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL auto_increment,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY  (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `fname`, `lname`, `dob`, `address`, `email`, `password`) VALUES
(1, 'Sahib', 'Jabbal', '16/06/1995', 'Westlands', 'sahibjabbal@hotmail.com', 'ssj123'),
(2, 'John', 'Smith', '12/05/1994', 'Westlands', 'john.smith@hotmail.com', 'jsmith'),
(3, 'James', 'David', '15/18/1993', 'Runda', 'james.david@hotmail.com', 'jamesdavid'),
(4, 'Anonymous', 'Hacker', '20/05/1997', 'Westlands', 'anonymous@gmail.com', 'qwerty'),
(5, 'Anonymous', 'Junior', '15/12/1993', 'Parklands', 'anonymousjr@yahoo.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL auto_increment,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY  (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `fname`, `lname`, `dob`, `address`, `email`, `password`) VALUES
(1, 'Sahib', 'Jabbal', '12/05/1979', 'Westlands', 'sahibjabbal@hotmail.com', 'ssj123'),
(2, 'qwerty', 'ytrewq', '21/08/1974`', 'Westlands	', 'qwerty@gmail.com', 'asdf');
