/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;

import com.thehowtotutorial.splashscreen.JSplash;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author SSJ
 */
public class SchoolLibrarySysytem extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SchoolLibrarySysytem main= new SchoolLibrarySysytem(); 
       
       
    }
    public SchoolLibrarySysytem(){
        JSplash splash= new JSplash(SchoolLibrarySysytem.class.getResource("Splash.jpg"), true, true, false,
                null, null, Color.CYAN ,Color.BLUE);
        try {
             splash.splashOn();
             splash.setProgress(0);
             Thread.sleep(1000);
             splash.setProgress(20,"Initialising application");
             Thread.sleep(1000);
             splash.setProgress(40,"Loading");
             Thread.sleep(1000);
             splash.setProgress(60,"Getting application ready");
             Thread.sleep(1000);
              splash.setProgress(80,"One moment please");
             Thread.sleep(1000);
             splash.splashOff();
              login login=new login();
              login.setVisible(true);
        } catch (Exception e) {
        }
    }
    
}
