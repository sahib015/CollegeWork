/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;


/**
 *
 * @author SSJ
 */
public class insertBooks extends JFrame {
    // variables for sql connection
     private Connection conn;
    private Statement st;
    private ResultSet rs;
     // Border 
     Border insertBooks_border=BorderFactory.createTitledBorder("New Books");
    // pannels
    private final JPanel mainPanel= new JPanel();
    private final JPanel logoPanel= new JPanel();
    private final JPanel dateTimePanel= new JPanel();
    private final JPanel newBookDetailsPanel= new JPanel();
    private final JPanel headerPanel= new JPanel();
    private final JPanel newBookPanel= new JPanel();
    private final JPanel newBookButtons= new JPanel();
    private final JPanel tittlePanel= new JPanel();
    // images
    ImageIcon logo= new ImageIcon(getClass().getResource("logo.jpg"));
    ImageIcon save= new ImageIcon(getClass().getResource("save.png"));
    ImageIcon exit= new ImageIcon(getClass().getResource("exit.png"));
    //Labels
      private final JLabel lbl_logo= new JLabel();
     private final JLabel lbl_date= new JLabel("Date and Time");
    private final JLabel lbl_bookTittle= new JLabel("Book Tittle: ");
    private final JLabel lbl_bookAuthor= new JLabel("Book Author: ");
    private final JLabel lbl_ISBN= new JLabel("ISBN: ");
    private final JLabel lbl_category= new JLabel("Category: ");
    private final JLabel lbl_availability= new JLabel("Availability:");
    private final JLabel lbl_header= new JLabel("New Books");
    // arrays
    String categories[]={
          "Fiction","Non-Fiction","Textbooks"
      };
     String availability[]={
          "Available","Non-available"
      };
    //text fields
    private final JTextField txt_bookTittle= new JTextField(15);
    private final JTextField txt_bookAuthor= new JTextField(15);
    private final JTextField txt_ISBN= new JTextField(15);
    private final JComboBox cmb_category= new JComboBox(categories);
   private final JComboBox cmb_availability= new JComboBox(availability);
 
    
    // buttons
    private final JButton btn_insert= new JButton("Save",save);
    private final JButton btn_cancel= new JButton("Cancel",exit);
    //constraints
    GridBagConstraints gbc= new GridBagConstraints();
    // font
    Font tittle= new Font(null,Font.BOLD,20);
    public final void currentDate(){
        
        Thread clock;
        clock = new Thread(){
            @Override
            public void run(){
                for(;;){
                    try {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//                        Date now = new Date();
//                        lbl_date.setText(sdfDate.format(now));
                        sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        clock.start();
        
        
    }
    public insertBooks(){
         // setting layouts
        mainPanel.setLayout(new BorderLayout());
        logoPanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new BorderLayout());
        dateTimePanel.setLayout(new BorderLayout());
        newBookDetailsPanel.setLayout(new GridBagLayout());
        newBookPanel.setLayout(new BorderLayout());
        newBookButtons.setLayout(new FlowLayout(FlowLayout.LEFT));
        tittlePanel.setLayout(new BorderLayout());
        
         // adding components to header
        // images    
        lbl_logo.setIcon(logo);
        logoPanel.add(lbl_logo);
        
        headerPanel.add(logoPanel,BorderLayout.WEST);
        //date
        
        currentDate();
        dateTimePanel.add(lbl_date,BorderLayout.NORTH);
        
        headerPanel.add(dateTimePanel,BorderLayout.EAST);
        // heading title
        lbl_header.setFont(tittle);
        tittlePanel.add(lbl_header,BorderLayout.CENTER);
        headerPanel.add(tittlePanel, BorderLayout.CENTER);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        // adding components
        gbc.gridx=0;
        gbc.gridy=0;
  
        newBookDetailsPanel.add(lbl_bookTittle,gbc);
        gbc.gridx=1;
        gbc.gridy=0;
      
        newBookDetailsPanel.add(txt_bookTittle,gbc);
        gbc.gridx=0;
        gbc.gridy=1;
      
       newBookDetailsPanel.add(lbl_bookAuthor,gbc);
        gbc.gridx=1;
        gbc.gridy=1;
       
       newBookDetailsPanel.add(txt_bookAuthor,gbc);
        gbc.gridx=0;
        gbc.gridy=2;
        
        newBookDetailsPanel.add(lbl_ISBN,gbc);
        gbc.gridx=1;
        gbc.gridy=2;
       
        newBookDetailsPanel.add(txt_ISBN,gbc);
        gbc.gridx=0;
        gbc.gridy=3;
       
        newBookDetailsPanel.add(lbl_category,gbc);
        
         
        gbc.gridx=1;
        gbc.gridy=3;
        gbc.gridwidth=4;
       newBookDetailsPanel.add(cmb_category,gbc);

        gbc.gridx=0;
        gbc.gridy=4;
        gbc.gridwidth=1;
        newBookDetailsPanel.add(lbl_availability,gbc);
        gbc.gridx=1;
        gbc.gridy=4;
        gbc.gridwidth=2;
        newBookDetailsPanel.add(cmb_availability,gbc);
       
        
        //adding buttons
      insertBookListener iLisetener= new insertBookListener();
      btn_cancel.addActionListener(iLisetener);
      btn_insert.addActionListener(iLisetener);
        newBookButtons.add(btn_cancel);
        newBookButtons.add(btn_insert);
  
        // adding to student reg Panel
       newBookPanel.add(newBookDetailsPanel,BorderLayout.NORTH);
        newBookPanel.add(newBookButtons,BorderLayout.EAST);
        
        //adding reg to main panel
        mainPanel.add(newBookPanel,BorderLayout.WEST);
         
        // adding main panel to window
        this.add(mainPanel);
        // window
        this.setSize(550,380);
        this.setTitle("Insert new Books");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }
    public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
     public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
     public void DBConnect(){
       try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/slibrary","slibrary","ssj123");
            st= conn.createStatement();
            
        } catch (Exception e) {
        System.out.println("Error: "+ e);
        
        }
    }
     private void Books(){
          try {
       
           
           String b_tittle= txt_bookTittle.getText();
           String b_author= txt_bookAuthor.getText();
           String b_isbn= txt_ISBN.getText();
           String b_category= cmb_category.getSelectedItem().toString();
           String b_availability= cmb_availability.getSelectedItem().toString();
          
           String sql= "insert into books(b_tittle,b_author,b_isbn,b_category,b_availability) values('"+b_tittle+"','"+b_author+"','"+b_isbn+"','"+b_category+"','"+b_availability+"')";
           st.executeUpdate(sql);
           JOptionPane.showMessageDialog(this,b_tittle+ " has successfully been added","Book Added",JOptionPane.INFORMATION_MESSAGE);       
            
        } catch (Exception e) {
            System.out.println(e);
        }
     }
     
     private class insertBookListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if(ae.getSource()==btn_cancel){
                close();  
            }else if(ae.getSource()==btn_insert){
                DBConnect();
                Books();
            }
        }
        
    }
}
