/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;
/**
 *
 * @author SSJ
 */
public class adminLogin extends JFrame{
    // variables for sql connection
     private Connection conn;
    private Statement st;
    private ResultSet rs;
    //borders
    Border admin_border=BorderFactory.createTitledBorder("Admin Login");
    
    //Panels
    private final JPanel mainPanel= new JPanel();
    private final JPanel logoPanel= new JPanel();
    private final JPanel imagePanel= new JPanel();
    private final JPanel headerPanel= new JPanel();
    private final JPanel dateTimePanel= new JPanel();
    private final JPanel adminLoginPanel= new JPanel();
    private final JPanel adminPanel= new JPanel();
    private final JPanel adminButtonsPanel= new JPanel();
    //images
    ImageIcon logo= new ImageIcon(getClass().getResource("logo.jpg"));
    ImageIcon login= new ImageIcon(getClass().getResource("login.png"));
    ImageIcon exit= new ImageIcon(getClass().getResource("exit.png"));
    ImageIcon admin= new ImageIcon(getClass().getResource("admin.png"));
   
    //Labels
    private final JLabel lbl_logo= new JLabel();
    private final JLabel lbl_date= new JLabel("Date and Time");
    private final JLabel lbl_image= new JLabel();
    private final JLabel lbl_ausername= new JLabel("Username");
    private final JLabel lbl_apassword= new JLabel("Password");
    
    //Text fields
    private final JTextField txt_ausername= new JTextField(15);
    private final JPasswordField txt_apassword= new JPasswordField(15);
    
    // buttons
    private final JButton btn_alogin= new JButton("Login",login);
    private final JButton btn_acanel= new JButton("Cancel",exit);
    
    //Box layout
    Box loginPanel =Box.createVerticalBox();
    
    public final void currentDate(){
        
        Thread clock;
        clock = new Thread(){
            @Override
            public void run(){
                for(;;){
                    try {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//                        Date now = new Date();
//                        lbl_date.setText(sdfDate.format(now));
                        sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        clock.start();
        
        
    }
    
    public adminLogin(){
        // setting layouts
        mainPanel.setLayout(new BorderLayout());
        logoPanel.setLayout(new BorderLayout());
        imagePanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new BorderLayout());
        dateTimePanel.setLayout(new BorderLayout());
        adminLoginPanel.setLayout(new GridLayout(0,2));
        adminPanel.setLayout(new BorderLayout());
        adminButtonsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        // setting borders
       adminPanel.setBorder(admin_border);
       
       // adding components to header
        // images    
      lbl_logo.setIcon(logo);
        logoPanel.add(lbl_logo);
        
        headerPanel.add(logoPanel,BorderLayout.WEST);
        
        //date
        
        currentDate();
        dateTimePanel.add(lbl_date,BorderLayout.NORTH);
        headerPanel.add(dateTimePanel,BorderLayout.EAST);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        // adding image to main panel
       lbl_image.setIcon(admin);
        imagePanel.add(lbl_image);
        mainPanel.add(imagePanel,BorderLayout.WEST);
        
        // adding components to admin login
        
        adminLoginPanel.add(lbl_ausername);
        adminLoginPanel.add(txt_ausername);
        adminLoginPanel.add(lbl_apassword);
        adminLoginPanel.add(txt_apassword);
        // adding buttons
        // admin
        adminListener aActionListener= new adminListener();
        btn_acanel.addActionListener(aActionListener);
        adminButtonsPanel.add(btn_acanel);
        btn_alogin.addActionListener(aActionListener);
       adminButtonsPanel.add(btn_alogin);
       
       // adding to admin panel
       //admin
        adminPanel.add(adminLoginPanel,BorderLayout.NORTH);
        adminPanel.add(adminButtonsPanel,BorderLayout.EAST);
        
      //adding admin Panel to login panel
        loginPanel.add(adminPanel);
        //adding login to main panel
        mainPanel.add(loginPanel,BorderLayout.EAST);
        
        
        
        // adding main panel to window
        this.add(mainPanel);
        //creating window
        this.setSize(500,250);
        this.setTitle("Admin Login");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }
      public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
      public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
         public void DBConnect(){

            try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/slibrary","slibrary","ssj123");
            st= conn.createStatement();
            
        } catch (Exception e) {
        System.out.println("Error: "+ e);
        
        }
    }
      
      public void aLogin(){
          String username=txt_ausername.getText();
        String password= txt_apassword.getText();
        String sql = "select * from admin where username='"+username+"' AND password='"+password+"'";
        
        try {
             

            rs=st.executeQuery(sql);
             
             if(rs.next()){
                 JOptionPane.showMessageDialog(this, "Welcome "+ username+" to Safi Buda Library Admin System","Success",JOptionPane.INFORMATION_MESSAGE);
                 adminMenu aAccess= new adminMenu();
                 close();
                 aAccess.setVisible(true);
             } else if(username.equals("")|| password.equals("")){
                 JOptionPane.showMessageDialog(this, "Please enter a username or password. All fields are required","Warning",JOptionPane.WARNING_MESSAGE);
                 
             }else{
                 JOptionPane.showMessageDialog(this, "Incorrect username or password, please try again","Error",JOptionPane.ERROR_MESSAGE);
             }
             
        } catch (Exception e) {
            System.out.println("Error: "+e);
        }
      }
      
    
    private class adminListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
             if(ae.getSource()==btn_acanel){
                 login login= new login();
                 
                 close();
                 login.setVisible(true);
                 
             } else if(ae.getSource()==btn_alogin){
                 DBConnect();
                 aLogin();
             }
        }
        
    }
}
