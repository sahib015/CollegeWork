/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;
/**
 *
 * @author SSJ
 */
public class aboutUs extends JFrame{
    // panels
     private final JPanel mainPanel= new JPanel();
     private final JPanel headerPanel= new JPanel();
    // private final JPanel infoPanel= new JPanel();
     private final JPanel detailPanel= new JPanel();
     private final JPanel closePanel= new JPanel();
     private final JPanel btnClosePanel= new JPanel();
     // text area
     private final JTextArea txt_about= new JTextArea(0,0);
     //images
     ImageIcon close= new ImageIcon(getClass().getResource("exit.png"));
     ImageIcon header= new ImageIcon(getClass().getResource("about_us.jpg"));
    //butotns
     private final JButton btn_close= new JButton("Close",close);
     // label
     private final JLabel lbl_about= new JLabel();
     //box 
     Box infoPanel =Box.createVerticalBox();
    public aboutUs(){
        // setting layouts
        mainPanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        //infoPanel.setLayout(new BorderLayout());
        detailPanel.setLayout(new BorderLayout());
        closePanel.setLayout(new BorderLayout());
        btnClosePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        
        //adding to headerPanel
        lbl_about.setIcon(header);
        headerPanel.add(lbl_about);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        
        // adding text
        // adding text area
        String details= " Product Version: 1.0 \n Java: 1.7.0_51, Java HotSpot(TM),Client VM 24.51-b03\n Runtime: Java(TM) SE Runtime Environement 1.7.0_51-b13 \n System: Windows 7 or higher \n Design and coded by: Sahib Jabbal";
        txt_about.setText(details);
        txt_about.setEditable(false);
        txt_about.setVisible(true);
        infoPanel.add(txt_about);
        closeActionListener closeListener= new closeActionListener();
        btn_close.addActionListener(closeListener);
        closePanel.add(btn_close,BorderLayout.EAST);
        btnClosePanel.add(closePanel,BorderLayout.CENTER);
       infoPanel.add(btnClosePanel);
        detailPanel.add(infoPanel);
        mainPanel.add(detailPanel);
        //adding main panel to window
        this.add(mainPanel);
        // creating window
        this.setSize(425,275);
        this.setTitle("About this software");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
        
    }
     public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
    public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
    private class closeActionListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
          close();
        }
        
    }
}
