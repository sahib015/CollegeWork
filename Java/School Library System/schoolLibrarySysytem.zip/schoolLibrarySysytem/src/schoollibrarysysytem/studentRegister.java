 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;



/**
 *
 * @author SSJ
 */
public class studentRegister extends JFrame{
    // variables for sql connection
     private Connection conn;
    private Statement st;
    private ResultSet rs;
    // Border 
     Border studentreg_border=BorderFactory.createTitledBorder("Student Register");
    // pannels
    private final JPanel mainPanel= new JPanel();
    private final JPanel logoPanel= new JPanel();
    private final JPanel dateTimePanel= new JPanel();
    private final JPanel studentRegDetailsPanel= new JPanel();
    private final JPanel headerPanel= new JPanel();
    private final JPanel studentRegPanel= new JPanel();
    private final JPanel studentRegButtons= new JPanel();
    private final JPanel tittlePanel= new JPanel();
    // images
    ImageIcon logo= new ImageIcon(getClass().getResource("logo.jpg"));
    ImageIcon reg= new ImageIcon(getClass().getResource("reg.png"));
    ImageIcon exit= new ImageIcon(getClass().getResource("exit.png"));
    //Labels
    private final JLabel lbl_logo= new JLabel();
     private final JLabel lbl_date= new JLabel("Date and Time");
    private final JLabel lbl_fname= new JLabel("First Name: ");
    private final JLabel lbl_lname= new JLabel("Last Name: ");
    private final JLabel lbl_dob= new JLabel("Date of Birth: ");
    private final JLabel lbl_address= new JLabel("Address: ");
    private final JLabel lbl_email= new JLabel("Email");
    private final JLabel lbl_password = new JLabel("Password");
    private final JLabel lbl_header= new JLabel("Student Registration");
    //text fields
    private final JTextField txt_fname= new JTextField(15);
    private final JTextField txt_lname= new JTextField(15);
    private final JTextField txt_dob= new JTextField(15);
    private final JTextArea txt_address= new JTextArea(5, 40);
    private final JTextField txt_email= new JTextField(15);
    private final JPasswordField txt_password= new JPasswordField(15);

    // buttons
    private final JButton btn_reg= new JButton("Register",reg);
    private final JButton btn_cancel= new JButton("Cancel",exit);
    //constraints
    GridBagConstraints gbc= new GridBagConstraints();
    // font
    Font tittle= new Font(null,Font.BOLD,20);
    public final void currentDate(){
        
        Thread clock;
        clock = new Thread(){
            @Override
            public void run(){
                for(;;){
                    try {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                        //Date now = new Date();
                        //lbl_date.setText(sdfDate.format(now));
                        sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        clock.start();
        
        
    }
    
    
    public studentRegister(){
        // setting layouts
        mainPanel.setLayout(new BorderLayout());
        logoPanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new BorderLayout());
        dateTimePanel.setLayout(new BorderLayout());
        studentRegDetailsPanel.setLayout(new GridBagLayout());
        studentRegPanel.setLayout(new BorderLayout());
        studentRegButtons.setLayout(new FlowLayout(FlowLayout.LEFT));
        tittlePanel.setLayout(new BorderLayout());
    
        // setting borders
        //studentRegPanel.setBorder(studentreg_border);
        
        // adding components to header
        // images    
        lbl_logo.setIcon(logo);
        logoPanel.add(lbl_logo);
        
        headerPanel.add(logoPanel,BorderLayout.WEST);
        //date
        
        currentDate();
        dateTimePanel.add(lbl_date,BorderLayout.NORTH);
        
        headerPanel.add(dateTimePanel,BorderLayout.EAST);
        // heading title
        lbl_header.setFont(tittle);
        tittlePanel.add(lbl_header,BorderLayout.CENTER);
        headerPanel.add(tittlePanel, BorderLayout.CENTER);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        // adding components
        gbc.gridx=0;
        gbc.gridy=0;
  
        studentRegDetailsPanel.add(lbl_fname,gbc);
        gbc.gridx=1;
        gbc.gridy=0;
      
        studentRegDetailsPanel.add(txt_fname,gbc);
        gbc.gridx=0;
        gbc.gridy=1;
      
        studentRegDetailsPanel.add(lbl_lname,gbc);
        gbc.gridx=1;
        gbc.gridy=1;
       
        studentRegDetailsPanel.add(txt_lname,gbc);
        gbc.gridx=0;
        gbc.gridy=2;
        
        studentRegDetailsPanel.add(lbl_dob,gbc);
        gbc.gridx=1;
        gbc.gridy=2;
       
        studentRegDetailsPanel.add(txt_dob,gbc);
        gbc.gridx=0;
        gbc.gridy=3;
       
        studentRegDetailsPanel.add(lbl_address,gbc);
        // adding text area
         txt_address.setEnabled(true);
        txt_address.setLineWrap(true);
       JScrollPane myScrollBar=new JScrollPane(txt_address,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
               JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        gbc.gridx=1;
        gbc.gridy=3;
        gbc.gridwidth=4;
        studentRegDetailsPanel.add(myScrollBar,gbc);
        // continuation of adding components
        gbc.gridx=0;
        gbc.gridy=4;
        gbc.gridwidth=1;
        studentRegDetailsPanel.add(lbl_email,gbc);
        gbc.gridx=1;
        gbc.gridy=4;
        gbc.gridwidth=2;
        studentRegDetailsPanel.add(txt_email,gbc);
        gbc.gridx=0;
        gbc.gridy=5;
        gbc.gridwidth=1;
        studentRegDetailsPanel.add(lbl_password,gbc);
        gbc.gridx=1;
        gbc.gridy=5;
        gbc.gridwidth=2;
        studentRegDetailsPanel.add(txt_password,gbc);
        
        //adding buttons
        studentRegListener sListener= new studentRegListener();
        btn_cancel.addActionListener(sListener);
        btn_reg.addActionListener(sListener);
        studentRegButtons.add(btn_cancel);
        studentRegButtons.add(btn_reg);
  
        // adding to student reg Panel
        studentRegPanel.add(studentRegDetailsPanel,BorderLayout.NORTH);
        studentRegPanel.add(studentRegButtons,BorderLayout.EAST);
        
        //adding reg to main panel
        mainPanel.add(studentRegPanel,BorderLayout.WEST);
         
        // adding main panel to window
        this.add(mainPanel);
        // window
        this.setSize(550,380);
        this.setTitle("Student Registration");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }
    public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
    public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
    // connecting to the database
    public void DBConnect(){
       try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/slibrary","slibrary","ssj123");
            st= conn.createStatement();
            
        } catch (Exception e) {
        System.out.println("Error: "+ e);
        
        }
    }
    public void sRegister(){
        try {
       
           
           String fname= txt_fname.getText();
           String lname= txt_lname.getText();
           String dob= txt_dob.getText();
           String address= txt_address.getText();
           String email= txt_email.getText();
           String password= txt_password.getText();
           String sql= "insert into students(fname,lname,dob,address,email,password) values('"+fname+"','"+lname+"','"+dob+"','"+address+"','"+email+"','"+password+"')";
           st.executeUpdate(sql);
           JOptionPane.showMessageDialog(this,"You have successfully registered, please use your "
                   + "user credentials to login","Registerd",JOptionPane.INFORMATION_MESSAGE);       
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    
    private class studentRegListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if(ae.getSource()==btn_cancel){
                login login= new login();
                close();
                login.setVisible(true);
                
            }else if (ae.getSource()==btn_reg){
                DBConnect();
                sRegister();
            }
        }
        
    }
}
