/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;


/**
 *
 * @author SSJ
 */
public class login extends JFrame{
        // variables for sql connection
         private Connection conn;
        private Statement st;
        private ResultSet rs;
    //borders
    Border student_border=BorderFactory.createTitledBorder("Student Login");
    Border teacher_border=BorderFactory.createTitledBorder("Teacher Login");
    //Panels
    private final JPanel mainPanel= new JPanel();
    private final JPanel logoPanel= new JPanel();
    private final JPanel imagePanel= new JPanel();
    private final JPanel headerPanel= new JPanel();
    private final JPanel dateTimePanel= new JPanel();
    private final JPanel studentLoginPanel= new JPanel();
    private final JPanel teacherLoginPanel= new JPanel();
    private final JPanel studentPanel= new JPanel();
    private final JPanel teacherPanel= new JPanel();
    private final JPanel studentButtonsPanel= new JPanel();
    private final JPanel teacherButtonsPanel= new JPanel();
    private final JPanel adminPanel= new JPanel();
    // images
    ImageIcon logo= new ImageIcon(getClass().getResource("logo.jpg"));
    ImageIcon login= new ImageIcon(getClass().getResource("login.png"));
    ImageIcon sign_up= new ImageIcon(getClass().getResource("reg.png"));
    ImageIcon exit= new ImageIcon(getClass().getResource("exit.png"));
    ImageIcon image= new ImageIcon(getClass().getResource("library.jpg"));
    //labels
    private final JLabel lbl_logo= new JLabel();
    private final JLabel lbl_date= new JLabel("Date and Time");
    private final JLabel lbl_image= new JLabel();
    private final JLabel lbl_susername= new JLabel("Email");
    private final JLabel lbl_spassword= new JLabel("Password");
    private final JLabel lbl_tusername= new JLabel("Email");
    private final JLabel lbl_tpassword= new JLabel("Password");
    private final JLabel lbl_admin= new JLabel("click here to login as admin");
    //Text fields
    private final JTextField txt_susername= new JTextField(15);
    private final JTextField txt_tusername= new JTextField(15);
    private final JPasswordField txt_spassword= new JPasswordField(15);
    private final JPasswordField txt_tpassword= new JPasswordField(15);
    //buttons
    private final JButton btn_ssignup= new JButton("Register",sign_up);
    private final JButton btn_slogin= new JButton("Login",login);
    private final JButton btn_tsignup= new JButton("Register",sign_up);
    private final JButton btn_tlogin= new JButton("Login",login);
    private final JButton btn_exit= new JButton("Exit",exit);
    //Box layout
    Box loginPanel =Box.createVerticalBox();
    
    
    
    public final void currentDate(){
        
        Thread clock;
        clock = new Thread(){
            @Override
            public void run(){
                for(;;){
                    try {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//                        Date now = new Date();
//                        lbl_date.setText(sdfDate.format(now));
                        sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        clock.start();
        
        
    }
    public login(){
        // setting layouts
        mainPanel.setLayout(new BorderLayout());
        logoPanel.setLayout(new BorderLayout());
        imagePanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new BorderLayout());
        dateTimePanel.setLayout(new BorderLayout());
        studentLoginPanel.setLayout(new GridLayout(0,2));
        teacherLoginPanel.setLayout(new GridLayout(0,2));
        studentPanel.setLayout(new BorderLayout());
        teacherPanel.setLayout(new BorderLayout());
        studentButtonsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        teacherButtonsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        adminPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
      
        // setting borders
 
        studentPanel.setBorder(student_border);
        teacherPanel.setBorder(teacher_border);
        // adding components to header
        // images    
      lbl_logo.setIcon(logo);
        logoPanel.add(lbl_logo);
        
        headerPanel.add(logoPanel,BorderLayout.WEST);
        
        //date
        
        currentDate();
        dateTimePanel.add(lbl_date,BorderLayout.NORTH);
        headerPanel.add(dateTimePanel,BorderLayout.EAST);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        // adding image to main panel
        lbl_image.setIcon(image);
        imagePanel.add(lbl_image);
        mainPanel.add(imagePanel,BorderLayout.WEST);
        
        // adding components to student and teacher login
        //student
     
        studentLoginPanel.add(lbl_susername);
        studentLoginPanel.add(txt_susername);
        studentLoginPanel.add(lbl_spassword);
        studentLoginPanel.add(txt_spassword);
        //teacher
       teacherLoginPanel.add(lbl_tusername);
        teacherLoginPanel.add(txt_tusername);
        teacherLoginPanel.add(lbl_tpassword);
        teacherLoginPanel.add(txt_tpassword);
        // adding buttons
        // student
        studentListener sactionListener= new studentListener();
        btn_ssignup.addActionListener(sactionListener);
        btn_slogin.addActionListener(sactionListener);
        studentButtonsPanel.add(btn_ssignup);
        studentButtonsPanel.add(btn_slogin);
        //teacher
        teacherListener tactionListener= new teacherListener();
        btn_tsignup.addActionListener(tactionListener);
        btn_tlogin.addActionListener(tactionListener);
        teacherButtonsPanel.add(btn_tsignup);
        teacherButtonsPanel.add(btn_tlogin);
        // exit
        
        // adding to studentPanel and teacher panel
       //student
        studentPanel.add(studentLoginPanel,BorderLayout.NORTH);
        studentPanel.add(studentButtonsPanel,BorderLayout.EAST);
        //teacher
        teacherPanel.add(teacherLoginPanel,BorderLayout.NORTH);
        teacherPanel.add(teacherButtonsPanel,BorderLayout.EAST);
        //adding student  and teacher Panel to login panel
     
        loginPanel.add(studentPanel);
        loginPanel.add(teacherPanel);
        
        //adding mouse listener to admin 
       adminMouse handler= new adminMouse();
       lbl_admin.addMouseListener(handler);
       lbl_admin.addMouseMotionListener(handler);
      adminPanel.add(lbl_admin);
//      
      
//        // adding exit
        exitListener exitSystem= new exitListener();
        btn_exit.addActionListener(exitSystem);
       adminPanel.add(btn_exit,BorderLayout.SOUTH);
       loginPanel.add(adminPanel);
        //adding login to main panel
       
        mainPanel.add(loginPanel,BorderLayout.EAST);
        
       
        
        // adding main panel to window
        this.add(mainPanel);
        
        //creating window
        this.setSize(600,400);
        this.setTitle("Login");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }
    public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
    
    public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
    // connecting to the database
    public void DBConnect(){
       try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/slibrary","slibrary","ssj123");
            st= conn.createStatement();
            
        } catch (Exception e) {
        System.out.println("Error: "+ e);
        
        }
    }
    // student login
    private void sLogin(){
        
        String username=txt_susername.getText();
        String password= txt_spassword.getText();
        String sql = "select * from students where email='"+username+"' AND password='"+password+"'";
        
        try {
             

            rs=st.executeQuery(sql);
             
             if(rs.next()){
                 JOptionPane.showMessageDialog(this, "Welcome "+ username+" to Safi Buda Library System","Success",JOptionPane.INFORMATION_MESSAGE);
                 studentMenu sAccess= new studentMenu();
                 close();
                 sAccess.setVisible(true);
             } else if(username.equals("")|| password.equals("")){
                 JOptionPane.showMessageDialog(this, "Please enter a username or password. All fields are required","Warning",JOptionPane.WARNING_MESSAGE);
                 
             }else{
                 JOptionPane.showMessageDialog(this, "Incorrect username or password, please try again","Error",JOptionPane.ERROR_MESSAGE);
             }
             
        } catch (Exception e) {
            System.out.println("Error: "+e);
        }
       
        
          
    }
    private void tLogin(){
        String username=txt_tusername.getText();
        String password= txt_tpassword.getText();
        String sql = "select * from teachers where email='"+username+"' AND password='"+password+"'";
        
        try {
             

            rs=st.executeQuery(sql);
             
             if(rs.next()){
                 JOptionPane.showMessageDialog(this, "Welcome "+ username+" to Safi Buda Library System","Success",JOptionPane.INFORMATION_MESSAGE);
                   teacherMenu teacherAccess= new teacherMenu();
                 close();
                 teacherAccess.setVisible(true);
             } else if(username.equals("")|| password.equals("")){
                 JOptionPane.showMessageDialog(this, "Please enter a username or password. All fields are required","Warning",JOptionPane.WARNING_MESSAGE);
                 
             }else{
                 JOptionPane.showMessageDialog(this, "Incorrect username or password, please try again","Error",JOptionPane.ERROR_MESSAGE);
             }
             
        } catch (Exception e) {
            System.out.println("Error: "+e);
        }
       
    }
    // action listener for student
    private class studentListener extends JFrame implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource()==btn_ssignup){
                studentRegister studentReg= new studentRegister();
               
                close();
               
                studentReg.setVisible(true);
            }else if(ae.getSource()==btn_slogin){
           
               DBConnect();
               sLogin();
               
                
            }
        }
        
    }
    private class teacherListener extends JFrame implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
             if (ae.getSource()==btn_tsignup){
               teacherRegister teacherReg= new teacherRegister();
                close();
               teacherReg.setVisible(true);
            }else if(ae.getSource()==btn_tlogin){
              DBConnect();
              tLogin();
            }
        }
        
    }
    private class exitListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource()==btn_exit){
               System.exit(0);
            }
        }
        
    }
    // mouse events for admin
    private class adminMouse extends JFrame implements MouseListener,MouseMotionListener{
        // mouse listener
        @Override
        public void mouseClicked(MouseEvent me) {
//            studentMenu menu= new studentMenu();
//            close();
//            menu.setVisible(true);
            adminLogin admin= new adminLogin();
            close();
            admin.setVisible(true);
            
         
        }

        @Override
        public void mousePressed(MouseEvent me) {
            //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent me) {
             //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseEntered(MouseEvent me) {
           //To change body of generated methods, choose Tools | Templates.
            Cursor handCursor= new Cursor(Cursor.HAND_CURSOR);
            lbl_admin.setForeground(Color.BLUE);
            lbl_admin.setCursor(handCursor);
        }

        @Override
        public void mouseExited(MouseEvent me) {
             //To change body of generated methods, choose Tools | Templates.
            Cursor defaultCursor= new Cursor(Cursor.DEFAULT_CURSOR);
             lbl_admin.setForeground(Color.BLACK);
             lbl_admin.setCursor(defaultCursor);
        }
        // mouse motion listener
        @Override
        public void mouseDragged(MouseEvent me) {
             //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseMoved(MouseEvent me) {
            //To change body of generated methods, choose Tools | Templates.
        }
        
    }
   
        
}
