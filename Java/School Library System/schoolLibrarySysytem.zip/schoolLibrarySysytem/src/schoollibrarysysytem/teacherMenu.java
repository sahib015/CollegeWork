/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.text.*;
import java.util.*;
import java.util.logging.*;
/**
 *
 * @author SSJ
 */
public class teacherMenu  extends JFrame{
     //Panels
    private final JPanel mainPanel= new JPanel();
    private final JPanel headerPanel= new JPanel();
    private final JPanel logoPanel= new JPanel();
    private final JPanel dateTimePanel= new JPanel();
    private final JPanel menuBarPanel= new JPanel();
    private final JPanel toolBarPanel= new JPanel();
    private final JPanel subPanel= new JPanel();
    //images
    ImageIcon logo= new ImageIcon(getClass().getResource("menu_icon.jpg"));
    ImageIcon exit= new ImageIcon(getClass().getResource("exit.png"));
    
    // menu bar
    private final JMenuBar menuBar= new JMenuBar();
    private final JMenu file,help;
    //toolbar
     private final JToolBar toolbar=new JToolBar();
    // menu items for help menu
    private final JMenuItem about_us,logout;
    //labels
    private final JLabel lbl_logo= new JLabel();
    private final JLabel lbl_date= new JLabel("Date and Time");
     // buttons for toolbar
    private final JButton btn_logout= new JButton(exit);
    public final void currentDate(){
        
        Thread clock;
        clock = new Thread(){
            @Override
            public void run(){
                for(;;){
                    try {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                        Date now = new Date();
                        lbl_date.setText(sdfDate.format(now));
                        sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        clock.start();
        
        
    }
    public teacherMenu(){
         // setting layouts
        mainPanel.setLayout(new BorderLayout());
        logoPanel.setLayout(new BorderLayout());
        headerPanel.setLayout(new BorderLayout());
        dateTimePanel.setLayout(new BorderLayout());
        menuBarPanel.setLayout(new BorderLayout());
        toolbar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBarPanel.setLayout(new BorderLayout());
        // adding components to header
        // creating menu bar
        // images    
        lbl_logo.setIcon(logo);
        menuBar.add(lbl_logo);
        //menu bar components
        //build file on the menu bar
        file= new JMenu("File");
        file.addSeparator();
        menuBar.add(file);
        logout= new JMenuItem("Logout");
        menuItemListener actionlogout= new menuItemListener();
        logout.addActionListener(actionlogout);
        file.addSeparator();
        file.add(logout);
        
        // build help on the menu bar
       help= new JMenu("Help");
       menuBar.add(help);
        // sub headings on help menu
        about_us=new JMenuItem("About Us", new ImageIcon(getClass().getResource("about.png")));
        //action event for opening about us
        menuItemListener actionabout= new menuItemListener();
        about_us.addActionListener(actionabout);
        help.add(about_us);
        
        //date
        
//        currentDate();
//        dateTimePanel.add(lbl_date,BorderLayout.NORTH);
//        menuBar.add(dateTimePanel,BorderLayout.EAST);
          // creatiing tool bar 
        btn_logout.setToolTipText("Logout");
      toolbarListener toolbarListener= new toolbarListener();
        btn_logout.addActionListener(toolbarListener);
        toolbar.add(btn_logout);
        
        // adding tool bar
        toolBarPanel.add(toolbar);
        // addin tool bar to main panel
        menuBarPanel.add(toolBarPanel,BorderLayout.SOUTH);
        // adding menu bar to main panel
        menuBarPanel.add(menuBar);
        headerPanel.add(menuBarPanel);
        mainPanel.add(headerPanel,BorderLayout.NORTH);
        
        // adding main panel to window
        mainPanel.add(subPanel,BorderLayout.CENTER);
        this.add(mainPanel);
        
        //creating window
         this.setSize(900,700);
        this.setTitle("Teachers");
        setIcon();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        this.setVisible(true);
        
    }
    public void close(){
        WindowEvent adminOpen= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(adminOpen);
    }
    public final void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
   private class menuItemListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if(ae.getSource()==about_us){
               aboutUs about= new aboutUs();
                about.setVisible(true);
            }
              if(ae.getSource()==logout){
               login login= new login();
                  close();
               login.setVisible(true);
            }
        }
        
       
   }
      private class toolbarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
          if (ae.getSource()==btn_logout){
                login login= new login();
                close();
                login.setVisible(true);
            }
        }
          
          
      }
   }
   

