/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoollibrarysysytem;
import java.sql.*;
/**
 *
 * @author SSJ
 */
public class DBConnect {
    // variables for sql connection
     private Connection conn;
    private Statement st;
    private ResultSet rs;
    public void DBConnect(){

            try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/slibrary","slibrary","ssj123");
            st= conn.createStatement();
            
        } catch (Exception e) {
        System.out.println("Error: "+ e);
        
        }
    }
}
